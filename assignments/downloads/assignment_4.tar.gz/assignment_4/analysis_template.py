#!/bin/python

import csv
import operator
import numpy as np
import matplotlib.pyplot as plt

#Read the data from the csvs that were output by quality_estimation.py
tweet_data = [row for row in csv.DictReader(open('data_quality_estimates.csv'))]
worker_data = [row for row in csv.DictReader(open('worker_quality_estimates.csv'))]


#Question 1 : What was your accuracy a) against the majority vote? b) against the controls? c) against the EM estimated labels? 
#Hint: (b) corresponds exactly to the percentage of HITs you approved, since you approved HITs if and only if the control was correct
correct = {'majority' : 0 , 'controls' : 0 , 'em' : 0}
total = 0
for row in tweet_data:
	for i in [1, 2, 3]:
		total += 1
		turker, turker_label, approved = row['worker%d'%i].split(':')
		#check if worker's label is correct according to the majority vote rule, and increment correct['majority'] if so
		#TODO YOUR CODE	
		#check if worker's label is correct according to the embedded controls rule, and increment correct['controls'] if so
		#TODO YOUR CODE	
		#check if worker's label is correct according to the em maximum liklihood labels, and increment correct['em'] if so
		#TODO YOUR CODE	
		
print 'Majority Vote:\t%.03f'%(float(correct['majority'])/total)
print 'Embedded Control:\t%.03f'%(float(correct['controls'])/total)
print 'Troia EM:\t%.03f'%(float(correct['em'])/total)

#Question 2 : How does each algorithm rank your workers? Do they agree on which workers are most/least trustworthy? 
#We will answer this question by looking at a graph of worker qualities. Because I really really like graphs.
workers = {'majority' : [] , 'controls' : [] , 'em' : []}
for row in worker_data:
	workers['majority'].append(float(row['majority_vote']))
	workers['controls'].append(float(row['embedded_control']))
	workers['em'].append(float(row['troia_em']))

#Each algorithm uses a different scale for evaluating worker qualities (look at the raw numbers, you will notice EM scores are much lower
#For this assignment, we only care about the relative ordering of workers, so we will normalize all worker qualities to be between 0 and 1, for comparison purposes
def normalize(lst) : return [(float(i) - min(lst)) / (max(lst) - min(lst)) for i in lst]

#Sort the workers by decreasing quality, according to majority vote
data = zip(normalize(workers['majority']), normalize(workers['controls']), normalize(workers['em']))
data = sorted(data, key=operator.itemgetter(0), reverse=True)

#Some picky things to make the graph look nice
width = 0.3
N = len(workers['majority'])

s1 = plt.bar(np.arange(N), [d[0] for d in data], width, color='b')
s2 = plt.bar(np.arange(N)+width, [d[1] for d in data], width, color='r')
s3 = plt.bar(np.arange(N)+2*width, [d[2] for d in data], width, color='g')

plt.title("Relative worker quality using different quality estimation algorithms")
plt.legend([s1,s2,s3], ['Majority Vote', 'Embedded Controls', 'Troia EM'], loc='lower left')
plt.xticks(np.arange(N)+width, ['worker%d'%i for i in np.arange(N)], size='small')
plt.savefig('worker_quality.png')
plt.show()
