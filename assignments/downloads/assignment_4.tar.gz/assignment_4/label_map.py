#!/bin/python

gold_labels = {
		'positive' : ['strongly positive', 'positive'], 
		'neutral' : ['neutral'], 
		'negative' : ['negative', 'strongly negative']
}

mturk_labels = {
		'strongly positive' : 'positive', 
		'positive' : 'positive', 
		'neutral' : 'neutral', 
		'negative' : 'negative',
		'strongly negative' : 'negative',
		'NA' : 'NA',
		'' : 'NA' #your turker was a lazy $%&*!. Blank answers will get treated as wrong.
}
